#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>

#include "plotwindow.h"
#include "ui_plotwindow.h"
#include <point.h>

// Names: Oceane Andreis
//
//

int PlotWindow::random_clicks_ = 0;

PlotWindow::PlotWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PlotWindow)
{
    // we need to set up the ui before we draw on our scene
    ui->setupUi(this);

    // scene is a pointer field of plot window
    scene = new QGraphicsScene;

    QGraphicsView * view = ui->plotGraphicsView;
    view->setScene(scene);
    view->setSceneRect(0,0,view->frameSize().width(),view->frameSize().height());


    srand(time(0));


    qDebug() << "Here's an example debugging statement";


    // Day 1, Task 2, number 5:
    // use the scene->addLine method to add lines to your scene for the x and y axes.
    // you may find the view->frameSize.[width()|height()] methods helpful as well.

       int width = view->frameSize().width();
       int height = view->frameSize().height();
       // Add a line:
      // scene->addLine(x_pos_start, y_pos_start, x_pos_end, y_pos_end)
       scene->addLine(width/2,0,width/2,height); //x stays the same but y moves, goes up and down
       scene->addLine(0,height/2,width,height/2); //y stays the same but x move, goes left and right

    // Day 1, Task 4, number 2:
    // connect the random button's &QAbstractButton::pressed event to the PlotWindow's new slot
    // connect(sender, sender signal, receiver, receiver slot)
    connect(ui->randomButton, &QAbstractButton::pressed, this, &PlotWindow::SlotTest);

}



PlotWindow::~PlotWindow()
{
    delete ui;
}

void PlotWindow::on_randomButton_clicked()
{
    //qDebug() << "Here's an example debugging statement";
    qDebug("Task 4 part 2");
}

void PlotWindow::SlotTest(){

    qDebug("Task 5 part 1");

}
